import React, { useState } from 'react'
import '../../assest/Login.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEnvelope, faEye, faEyeSlash } from '@fortawesome/free-regular-svg-icons'
import { faKey } from '@fortawesome/free-solid-svg-icons'
import { Link } from 'react-router-dom'
import { Helmet } from 'react-helmet';
function Login() {
  const [icon, setIcon] = useState(faEyeSlash);
  const showPassword = () => {
    var x = document.getElementById("password");
    if (x.type === "password") {
      x.type = "text";
      setIcon(faEye);
    } else {
      x.type = "password";
      setIcon(faEyeSlash);
    }
  }
  return (
    <div>
      <Helmet>
        <title>Đăng nhập</title>
        <meta name="description" content='Đăng nhập' />
      </Helmet>
      <section>
        <div className="form-box">
          <div className="form-value">
            <form action="">
              <h3>Đăng nhập</h3>
              <div className="inputbox">
                <i><FontAwesomeIcon icon={faEnvelope} /></i>
                <input type="text" required />
                <label>Email</label>
              </div>
              <div className="inputbox">
                <i><FontAwesomeIcon icon={faKey} /></i>
                <FontAwesomeIcon icon={icon} onClick={showPassword} className='eye' />
                <input type="password" id='password' required />
                <label>Mật khẩu</label>
              </div>
              <div className="forget position-relative">
                <label></label>
                <Link to={'/forget'}>Quên mật khẩu?</Link>
              </div>
              <button className='glow-on-hover position-relative'>
                Đăng nhập
              </button>
              <div className="register position-relative">
                <p>Nếu bạn chưa có tài khoản, <Link to={'/signin'}>đăng ký ngay</Link></p>
              </div>
            </form>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Login